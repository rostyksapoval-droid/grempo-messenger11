const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Раздача статических файлов из папки public
app.use(express.static('public'));

// Обработка подключений Socket.IO
io.on('connection', (socket) => {
  console.log('Новый пользователь подключился:', socket.id);

  // Получаем имя пользователя и оповещаем всех
  socket.on('set username', (username) => {
    socket.username = username;
    // Уведомление всем, кроме отправителя
    socket.broadcast.emit('user joined', `${username} присоединился к чату`);
    // Отправляем приветствие самому пользователю
    socket.emit('welcome', `Добро пожаловать, ${username}!`);
  });

  // Обработка входящего сообщения
  socket.on('chat message', (msg) => {
    // Рассылаем сообщение всем (включая отправителя)
    io.emit('chat message', {
      username: socket.username,
      text: msg,
      time: new Date().toLocaleTimeString()
    });
  });

  // Отключение пользователя
  socket.on('disconnect', () => {
    if (socket.username) {
      console.log(`${socket.username} отключился`);
      socket.broadcast.emit('user left', `${socket.username} покинул чат`);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});