const socket = io();

// DOM-элементы
const loginContainer = document.getElementById('login-container');
const chatContainer = document.getElementById('chat-container');
const usernameInput = document.getElementById('username-input');
const joinBtn = document.getElementById('join-btn');
const loginError = document.getElementById('login-error');
const currentUsernameSpan = document.getElementById('current-username');
const logoutBtn = document.getElementById('logout-btn');
const messagesDiv = document.getElementById('messages');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');

let currentUsername = '';

// Вход в чат
joinBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  if (!username) {
    loginError.style.display = 'block';
    return;
  }
  currentUsername = username;
  socket.emit('set username', username);
  loginContainer.style.display = 'none';
  chatContainer.style.display = 'flex';
  currentUsernameSpan.textContent = username;
  loginError.style.display = 'none';
  messageInput.focus();
});

// Вход по Enter в поле имени
usernameInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    joinBtn.click();
  }
});

// Выход из чата
logoutBtn.addEventListener('click', () => {
  socket.disconnect();
  location.reload(); // простой способ вернуться на страницу входа
});

// Отправка сообщения
function sendMessage() {
  const text = messageInput.value.trim();
  if (text) {
    socket.emit('chat message', text);
    messageInput.value = '';
  }
}

sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

// Получение приветствия
socket.on('welcome', (msg) => {
  addSystemMessage(msg);
});

// Подключение нового пользователя
socket.on('user joined', (msg) => {
  addSystemMessage(msg);
});

// Пользователь вышел
socket.on('user left', (msg) => {
  addSystemMessage(msg);
});

// Новое сообщение
socket.on('chat message', (data) => {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message');
  if (data.username === currentUsername) {
    messageElement.classList.add('own');
  }
  const usernameSpan = document.createElement('span');
  usernameSpan.className = 'username';
  usernameSpan.textContent = data.username;
  const timeSpan = document.createElement('span');
  timeSpan.className = 'time';
  timeSpan.textContent = data.time;
  const textNode = document.createTextNode(data.text);

  messageElement.appendChild(usernameSpan);
  messageElement.appendChild(textNode);
  messageElement.appendChild(timeSpan);
  messagesDiv.appendChild(messageElement);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
});

// Системное сообщение
function addSystemMessage(text) {
  const msgDiv = document.createElement('div');
  msgDiv.className = 'system-message';
  msgDiv.textContent = text;
  messagesDiv.appendChild(msgDiv);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}